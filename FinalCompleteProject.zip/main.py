from loginfile import Profiles
from pvp import PlayerVsPlayer

def main():
  # classProfiles = Profiles()
  # classProfiles.Layout()
  x = PlayerVsPlayer()
  x.playGame()

main()